/* 日田市AEDナビ — script.js（大分県日田市専用）
 * AED.xlsx を読み込み、出発地から最も近い（徒歩経路が最短の）AEDへの経路を表示する。
 *
 * 最短経路の求め方:
 *   1. 全AEDの直線距離（ハバーサイン）を計算し、近い順に上位 N 件を候補にする
 *   2. 候補ごとに徒歩ルートを OSRM で取得し、実際の経路距離が最短のものを選ぶ
 *   3. 経路が取得できなかった候補は「直線距離×1.3」で概算する（地図上は点線）
 */
(function () {
  'use strict';

  /* ===== 設定 ===== */
  const CONFIG = {
    xlsxUrl: 'AED.xlsx',
    candidateCount: 5,          // 経路を計算する候補数
    walkMetersPerMin: 80,       // 徒歩速度（m/分）
    detourFactor: 1.3,          // 経路未取得時の概算係数
    routeEndpoint: 'https://routing.openstreetmap.de/routed-foot/route/v1/foot/',
    routeTimeoutMs: 9000,
    geocodeEndpoint: 'https://msearch.gsi.go.jp/address-search/AddressSearch?q=',
    // Googleマップに近い配色の CARTO Voyager（標準）と、国土地理院の航空写真
    tiles: {
      standard: {
        url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
        options: {
          subdomains: 'abcd', maxZoom: 20,
          attribution: '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors © <a href="https://carto.com/attributions" target="_blank" rel="noopener">CARTO</a>'
        }
      },
      photo: {
        url: 'https://cyberjapandata.gsi.go.jp/xyz/seamlessphoto/{z}/{x}/{y}.jpg',
        options: {
          maxNativeZoom: 18, maxZoom: 20,
          attribution: '<a href="https://maps.gsi.go.jp/development/ichiran.html" target="_blank" rel="noopener">国土地理院</a>'
        }
      }
    },
    // 建物を白く描けるベクタータイル（OpenFreeMap）。読み込めない場合は上の standard（画像タイル）にフォールバック
    vector: {
      styleUrl: 'https://tiles.openfreemap.org/styles/bright',
      attribution: '<a href="https://openfreemap.org" target="_blank" rel="noopener">OpenFreeMap</a> © <a href="https://openmaptiles.org/" target="_blank" rel="noopener">OpenMapTiles</a> Data from <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>',
      buildingFill: '#ffffff',      // 建物の塗り
      buildingOutline: '#b4aea6',   // 建物の輪郭（白い地面に溶けないように）
      landColor: '#e9ebe6',         // 地面の色（建物の白を目立たせる）
      timeoutMs: 7000
    },
    // 日田市（JR日田駅付近）を初期表示の中心にする
    defaultCenter: [33.3224, 130.9441],   // 大分県立日田高等学校付近
    defaultZoom: 14,
    minZoom: 9,
    // 日田市全域を余裕を持って含む範囲（南端〜北端, 西端〜東端）。市外判定に使う
    areaBounds: { south: 33.05, north: 33.60, west: 130.55, east: 131.35 },
    areaName: '日田市'
  };

  const inArea = (p) =>
    p.lat >= CONFIG.areaBounds.south && p.lat <= CONFIG.areaBounds.north &&
    p.lng >= CONFIG.areaBounds.west && p.lng <= CONFIG.areaBounds.east;

  /* Excel見出しの別名（正規化後の文字列で比較） */
  const HEADER_ALIASES = {
    name:    ['施設名', '名称', '名前', '設置施設', 'name'],
    address: ['住所', '所在地', 'address'],
    lat:     ['緯度', 'lat', 'latitude'],
    lng:     ['経度', 'lng', 'lon', 'long', 'longitude'],
    place:   ['設置場所', '設置位置', '設置箇所', '場所', 'place', 'location'],
    hours:   ['利用可能時間', '利用時間', '使用可能時間', '利用可能日時', 'hours'],
    tel:     ['電話番号', '電話', 'tel', 'phone'],
    note:    ['備考', 'メモ', 'note', 'notes']
  };

  /* ===== 状態 ===== */
  const state = {
    aeds: [],
    markers: new Map(),      // aed.id -> L.marker
    start: null,             // {lat, lng}
    cache: new Map(),        // aed.id -> {distance, approx, coords, straight}
    ranked: [],              // [{aed, info}] 近い順
    selected: null,
    picking: false,
    only24: false,
    outside: false,          // 出発地が日田市周辺の外か
    token: 0                 // 検索の競合防止
  };

  let map, startMarker, accuracyCircle, routeLayers = [];

  /* ===== DOM ===== */
  const $ = (id) => document.getElementById(id);
  const ui = {
    map: $('map'),
    btnLocate: $('btnLocate'),
    btnPick: $('btnPick'),
    chk24: $('chk24'),
    status: $('status'),
    result: $('result'),
    candidates: $('candidates'),
    candList: $('candList'),
    dataInfo: $('dataInfo')
  };

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;   // textContent でXSSを防ぐ
    return node;
  }

  function setStatus(message, kind) {
    ui.status.textContent = message || '';
    ui.status.className = 'status' + (kind ? ' ' + kind : '');
  }

  /* ===== ユーティリティ ===== */
  const normalize = (s) => String(s).normalize('NFKC').replace(/\s+/g, '').toLowerCase();

  function parseNumber(v) {
    if (typeof v === 'number') return v;
    const n = parseFloat(String(v).normalize('NFKC').replace(/[^\d.\-]/g, ''));
    return Number.isFinite(n) ? n : NaN;
  }

  function haversine(a, b) {
    const R = 6371000;
    const rad = Math.PI / 180;
    const dLat = (b.lat - a.lat) * rad;
    const dLng = (b.lng - a.lng) * rad;
    const h = Math.sin(dLat / 2) ** 2 +
      Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(h));
  }

  function formatDistance(m) {
    if (m < 1000) return { value: String(Math.max(10, Math.round(m / 10) * 10)), unit: 'm' };
    return { value: (m / 1000).toFixed(1), unit: 'km' };
  }

  const walkMinutes = (m) => Math.max(1, Math.round(m / CONFIG.walkMetersPerMin));

  /* ===== Excel読み込み ===== */
  async function loadAEDs() {
    let res;
    try {
      res = await fetch(CONFIG.xlsxUrl, { cache: 'no-cache' });
    } catch (e) {
      throw new Error('fetch');
    }
    if (!res.ok) throw new Error('http ' + res.status);

    const wb = XLSX.read(await res.arrayBuffer(), { type: 'array' });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    if (!rows.length) throw new Error('empty');

    // 見出し名 -> 内部キー
    const colMap = {};
    Object.keys(rows[0]).forEach((header) => {
      const h = normalize(header);
      for (const key of Object.keys(HEADER_ALIASES)) {
        if (!colMap[key] && HEADER_ALIASES[key].some((alias) => normalize(alias) === h)) {
          colMap[key] = header;
        }
      }
    });
    if (!colMap.lat || !colMap.lng) throw new Error('columns');

    const aeds = [];
    const pending = [];     // 座標が空で、住所から位置を取得する行
    let skipped = 0;

    rows.forEach((row, i) => {
      const get = (k) => (colMap[k] ? String(row[colMap[k]]).trim() : '');
      const hours = get('hours');
      const base = {
        id: i,
        name: get('name') || 'AED（名称未登録）',
        address: get('address'),
        place: get('place'),
        hours,
        tel: get('tel'),
        note: get('note'),
        is24h: /24時間|24h|終日|常時/i.test(hours.normalize('NFKC')),
        geocoded: false
      };
      if (!base.name && !base.address) { skipped++; return; }

      let lat = parseNumber(row[colMap.lat]);
      let lng = parseNumber(row[colMap.lng]);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
        if (base.address) pending.push(base); else skipped++;
        return;
      }
      // 緯度経度が逆に入力されている場合の救済（日本付近など経度が90超の地域）
      if (lat > 90 && lng <= 90) { [lat, lng] = [lng, lat]; }
      if (Math.abs(lat) > 90 || Math.abs(lng) > 180) { skipped++; return; }

      aeds.push(Object.assign(base, { lat, lng }));
    });

    if (!aeds.length && !pending.length) throw new Error('empty');
    return { aeds, pending, skipped };
  }


  /* ===== 住所 → 緯度経度（国土地理院 住所検索API） =====
   * AED.xlsx の緯度・経度が空欄の行だけ、住所から位置を取得する。
   * 結果は localStorage に保存し、2回目以降は通信しない。 */
  const GEO_CACHE_KEY = 'aed-geocode-v1';

  function readGeoCache() {
    try { return JSON.parse(localStorage.getItem(GEO_CACHE_KEY)) || {}; } catch (e) { return {}; }
  }
  function writeGeoCache(cache) {
    try { localStorage.setItem(GEO_CACHE_KEY, JSON.stringify(cache)); } catch (e) { /* 保存できなくても動作に影響なし */ }
  }

  async function geocodeAddress(address) {
    const query = address.normalize('NFKC').replace(/^大分県/, '').replace(/\s+/g, '');
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    try {
      const res = await fetch(CONFIG.geocodeEndpoint + encodeURIComponent(query), { signal: ctrl.signal });
      if (!res.ok) throw new Error('http ' + res.status);
      const list = await res.json();
      // 対象市内の結果のうち、住所表記が最も詳細（長い）ものを採用
      const hit = (Array.isArray(list) ? list : [])
        .filter((f) => f && f.geometry && f.geometry.coordinates && String(f.properties && f.properties.title).includes(CONFIG.areaName))
        .sort((a, b) => String(b.properties.title).length - String(a.properties.title).length)[0];
      if (!hit) return null;
      const [lng, lat] = hit.geometry.coordinates;
      return Number.isFinite(lat) && Number.isFinite(lng) ? { lat, lng } : null;
    } catch (e) {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  async function geocodePending(pending) {
    const cache = readGeoCache();
    const resolved = [];
    let failed = 0;

    await Promise.all(pending.map(async (aed) => {
      let pos = cache[aed.address];
      if (!pos) {
        pos = await geocodeAddress(aed.address);
        if (pos) cache[aed.address] = pos;
      }
      if (pos) resolved.push(Object.assign(aed, { lat: pos.lat, lng: pos.lng, geocoded: true }));
      else failed++;
    }));

    writeGeoCache(cache);
    resolved.sort((a, b) => a.id - b.id);
    return { resolved, failed };
  }

  /* ===== 地図 ===== */
  function initMap() {
    map = L.map(ui.map, { zoomControl: false, minZoom: CONFIG.minZoom, maxZoom: 20 }).setView(CONFIG.defaultCenter, CONFIG.defaultZoom);

    const base = {
      standard: L.tileLayer(CONFIG.tiles.standard.url, CONFIG.tiles.standard.options),
      photo: L.tileLayer(CONFIG.tiles.photo.url, CONFIG.tiles.photo.options)
    };
    let currentBase = 'standard';
    base.standard.addTo(map);          // まず画像タイルで即表示し、ベクター（建物が白）が用意できたら差し替える
    upgradeToVectorBase();

    // Googleマップ風コントロール: 右上=航空写真切替 / 右下=現在地＋ズーム
    L.control.zoom({ position: 'bottomright', zoomInTitle: '拡大', zoomOutTitle: '縮小' }).addTo(map);
    addControl('bottomright', 'gm-btn gm-locate', ICON_LOCATE, '現在地を表示', locate);
    const layerBtn = addControl('topright', 'gm-btn gm-layer', '', '地図の種類を切り替え', () => {
      map.removeLayer(base[currentBase]);
      currentBase = currentBase === 'standard' ? 'photo' : 'standard';
      base[currentBase].addTo(map);
      updateLayerBtn();
    });
    function updateLayerBtn() {
      const next = currentBase === 'standard' ? '航空写真' : '地図';
      layerBtn.textContent = '';
      layerBtn.appendChild(el('span', 'gm-layer-thumb ' + (currentBase === 'standard' ? 'is-photo' : 'is-map')));
      layerBtn.appendChild(el('span', 'gm-layer-label', next));
    }
    updateLayerBtn();

    async function upgradeToVectorBase() {
      const layer = await createVectorLayer();
      if (!layer) return;              // 失敗時は画像タイルのまま
      const raster = base.standard;
      base.standard = layer;
      if (currentBase === 'standard') {
        layer.addTo(map);
        map.removeLayer(raster);
      }
    }

    map.on('click', (e) => {
      if (!state.picking) return;
      setPicking(false);
      setStart({ lat: e.latlng.lat, lng: e.latlng.lng }, 0);
      search();
    });
  }


  /* ===== ベクター地図（建物を白にする） ===== */
  function webglAvailable() {
    try {
      const c = document.createElement('canvas');
      return !!(c.getContext('webgl2') || c.getContext('webgl'));
    } catch (e) { return false; }
  }

  function customizeStyle(style) {
    const v = CONFIG.vector;
    style.layers.forEach((l) => {
      const id = String(l.id).toLowerCase();
      const src = String(l['source-layer'] || '');
      l.paint = l.paint || {};

      // 地面の色
      if (l.type === 'background') l.paint['background-color'] = v.landColor;

      // 建物は白（輪郭つき）
      if (src === 'building' || id.includes('building')) {
        if (l.type === 'fill') {
          l.paint['fill-color'] = v.buildingFill;
          l.paint['fill-outline-color'] = v.buildingOutline;
          l.paint['fill-opacity'] = 1;
        } else if (l.type === 'fill-extrusion') {
          l.paint['fill-extrusion-color'] = v.buildingFill;
          l.paint['fill-extrusion-opacity'] = 1;
        } else if (l.type === 'line') {
          l.paint['line-color'] = v.buildingOutline;
        }
      }

      // 地名はできるだけ日本語表記に
      if (l.type === 'symbol' && l.layout && l.layout['text-field'] &&
          JSON.stringify(l.layout['text-field']).includes('name')) {
        l.layout['text-field'] = ['coalesce', ['get', 'name:ja'], ['get', 'name']];
      }
    });
    return style;
  }

  async function createVectorLayer() {
    if (typeof L.maplibreGL !== 'function' || typeof maplibregl === 'undefined' || !webglAvailable()) return null;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), CONFIG.vector.timeoutMs);
    try {
      const res = await fetch(CONFIG.vector.styleUrl, { signal: ctrl.signal });
      if (!res.ok) throw new Error('http ' + res.status);
      const style = customizeStyle(await res.json());
      return L.maplibreGL({ style, attribution: CONFIG.vector.attribution });
    } catch (e) {
      console.warn('ベクター地図を読み込めないため、画像タイルを使用します', e);
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  const ICON_LOCATE =
    '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm8.94 3A8.994 8.994 0 0 0 13 3.06V1h-2v2.06A8.994 8.994 0 0 0 3.06 11H1v2h2.06A8.994 8.994 0 0 0 11 20.94V23h2v-2.06A8.994 8.994 0 0 0 20.94 13H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/></svg>';

  function addControl(position, className, html, title, onClick) {
    let button;
    const Ctl = L.Control.extend({
      options: { position },
      onAdd() {
        button = L.DomUtil.create('button', className);
        button.type = 'button';
        button.title = title;
        button.setAttribute('aria-label', title);
        button.innerHTML = html;       // 固定のSVG文字列のみ（外部入力は使わない）
        L.DomEvent.disableClickPropagation(button);
        L.DomEvent.on(button, 'click', onClick);
        return button;
      }
    });
    new Ctl().addTo(map);
    return button;
  }

  /* 画面幅に応じた fitBounds の余白（PCは左の情報カードを避ける） */
  function fitOptions(extra) {
    const wide = window.matchMedia('(min-width: 761px)').matches;
    const base = wide
      ? { paddingTopLeft: [440, 50], paddingBottomRight: [80, 50] }
      : { padding: [50, 50] };
    return Object.assign(base, extra || {});
  }

  function aedIcon(aed) {
    const isTarget = state.selected && state.selected.id === aed.id;
    const dim = state.only24 && !aed.is24h;
    const w = isTarget ? 38 : 28;
    const h = Math.round(w * 1.5);
    const color = isTarget ? '#ea4335' : (dim ? '#9aa0a6' : '#188038');   // 選択=Googleの赤 / 通常=緑
    const svg =
      '<svg viewBox="0 0 24 36" width="' + w + '" height="' + h + '" aria-hidden="true">' +
      '<path d="M12 0C5.4 0 0 5.4 0 12c0 9 12 24 12 24s12-15 12-24C24 5.4 18.6 0 12 0z" fill="' + color + '"/>' +
      '<path d="M12 0C5.4 0 0 5.4 0 12c0 9 12 24 12 24s12-15 12-24C24 5.4 18.6 0 12 0z" fill="none" stroke="rgba(0,0,0,.25)" stroke-width="1"/>' +
      '<path fill="#fff" d="M10.4 6.5h3.2v3.9h3.9v3.2h-3.9v3.9h-3.2v-3.9H6.5v-3.2h3.9z"/>' +
      '</svg>';
    return L.divIcon({
      className: 'g-pin' + (isTarget ? ' is-target' : ''),
      html: svg,
      iconSize: [w, h],
      iconAnchor: [w / 2, h]
    });
  }

  function addMarkers() {
    state.aeds.forEach((aed) => {
      const marker = L.marker([aed.lat, aed.lng], {
        icon: aedIcon(aed),
        title: aed.name,
        keyboard: true,
        riseOnHover: true
      }).addTo(map);
      marker.on('click', () => showAED(aed));
      state.markers.set(aed.id, marker);
    });
    const local = state.aeds.filter(inArea);
    if (local.length) {
      map.fitBounds(L.latLngBounds(local.map((a) => [a.lat, a.lng])).pad(0.1), fitOptions({ maxZoom: 15 }));
    }
  }

  function refreshIcons() {
    state.aeds.forEach((aed) => {
      const m = state.markers.get(aed.id);
      if (!m) return;
      m.setIcon(aedIcon(aed));
      m.setZIndexOffset(state.selected && state.selected.id === aed.id ? 1000 : 0);
    });
  }

  function clearRoute() {
    routeLayers.forEach((l) => map.removeLayer(l));
    routeLayers = [];
  }

  function drawRoute(info) {
    clearRoute();
    if (!state.start) return;

    let latlngs;
    if (info.coords) {
      latlngs = info.coords.map(([lng, lat]) => [lat, lng]);
      // Googleマップの徒歩ルートのように、白縁付きの青いドット線
      const dots = { dashArray: '0.1 13', lineCap: 'round', lineJoin: 'round' };
      routeLayers.push(L.polyline(latlngs, Object.assign({ color: '#fff', weight: 13, opacity: 1 }, dots)).addTo(map));
      routeLayers.push(L.polyline(latlngs, Object.assign({ color: '#4285f4', weight: 8, opacity: 1 }, dots)).addTo(map));
    } else {
      latlngs = [[state.start.lat, state.start.lng], [info.aed.lat, info.aed.lng]];
      routeLayers.push(L.polyline(latlngs, { color: '#4285f4', weight: 3, dashArray: '6 8', opacity: .8 }).addTo(map));
    }

    // 経路の中間に「徒歩 N分」のバッジ
    const mid = latlngs[Math.floor(latlngs.length / 2)];
    const d = formatDistance(info.distance);
    const badge = L.divIcon({
      className: 'route-badge-wrap',
      html: '<div class="route-badge"><strong>徒歩 ' + (info.approx ? '約' : '') + walkMinutes(info.distance) + '分</strong><span>' + d.value + ' ' + d.unit + '</span></div>',
      iconSize: [92, 38],
      iconAnchor: [46, 19]
    });
    routeLayers.push(L.marker(mid, { icon: badge, interactive: false, keyboard: false, zIndexOffset: 500 }).addTo(map));

    map.fitBounds(L.latLngBounds(latlngs).pad(0.15), fitOptions({ maxZoom: 18 }));
  }

  /* ===== 出発地 ===== */
  function setStart(pos, accuracy) {
    state.start = pos;
    state.cache = new Map();
    state.ranked = [];

    if (startMarker) map.removeLayer(startMarker);
    if (accuracyCircle) { map.removeLayer(accuracyCircle); accuracyCircle = null; }

    startMarker = L.marker([pos.lat, pos.lng], {
      icon: L.divIcon({ className: '', html: '<div class="me-halo"></div><div class="me-pin"></div>', iconSize: [24, 24], iconAnchor: [12, 12] }),
      title: '出発地',
      interactive: false,
      zIndexOffset: 2000
    }).addTo(map);

    if (accuracy && accuracy > 20) {
      accuracyCircle = L.circle([pos.lat, pos.lng], {
        radius: accuracy, color: '#4285f4', weight: 1, fillColor: '#4285f4', fillOpacity: .15, interactive: false
      }).addTo(map);
    }
  }

  function locate() {
    if (!state.aeds.length) { setStatus('AEDデータを読み込み中です。少し待ってからもう一度押してください。'); return; }
    if (ui.btnLocate.disabled) return;
    if (!navigator.geolocation) {
      setStatus('この端末では現在地を取得できません。「地図をタップして出発地を指定」を使ってください。', 'error');
      return;
    }
    setPicking(false);
    setStatus('現在地を取得中…', 'busy');
    ui.btnLocate.disabled = true;

    navigator.geolocation.getCurrentPosition(
      (p) => {
        ui.btnLocate.disabled = false;
        setStart({ lat: p.coords.latitude, lng: p.coords.longitude }, p.coords.accuracy);
        search();
      },
      (err) => {
        ui.btnLocate.disabled = false;
        const reason = err.code === 1
          ? '位置情報の利用が許可されていません。ブラウザの設定を確認してください。'
          : '現在地を取得できませんでした。';
        setStatus(reason + ' 地図をタップして出発地を指定することもできます。', 'error');
        setPicking(true);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  }

  function setPicking(on) {
    state.picking = on;
    ui.btnPick.setAttribute('aria-pressed', String(on));
    ui.map.classList.toggle('picking', on);
    if (on) setStatus('地図上の出発地点をタップしてください。');
  }

  /* ===== 経路計算 ===== */
  async function fetchWalkingRoute(from, to) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), CONFIG.routeTimeoutMs);
    try {
      const url = CONFIG.routeEndpoint +
        from.lng + ',' + from.lat + ';' + to.lng + ',' + to.lat +
        '?overview=full&geometries=geojson';
      const res = await fetch(url, { signal: ctrl.signal });
      if (!res.ok) throw new Error('http ' + res.status);
      const data = await res.json();
      if (data.code !== 'Ok' || !data.routes || !data.routes.length) throw new Error('no route');
      return { distance: data.routes[0].distance, coords: data.routes[0].geometry.coordinates };
    } finally {
      clearTimeout(timer);
    }
  }

  async function computeInfo(aed) {
    const straight = haversine(state.start, aed);
    try {
      const r = await fetchWalkingRoute(state.start, aed);
      return { aed, straight, distance: r.distance, coords: r.coords, approx: false };
    } catch (e) {
      return { aed, straight, distance: straight * CONFIG.detourFactor, coords: null, approx: true };
    }
  }

  async function search() {
    if (!state.start) return;
    const token = ++state.token;

    state.outside = !inArea(state.start);
    setStatus('最短経路を計算中…', 'busy');
    ui.result.hidden = true;
    ui.candidates.hidden = true;
    clearRoute();

    const pool = state.only24 ? state.aeds.filter((a) => a.is24h) : state.aeds;
    if (!pool.length) {
      setStatus('条件に合うAEDがありません。「24時間使えるAEDのみ」を外してください。', 'error');
      return;
    }

    const nearest = pool
      .map((aed) => ({ aed, straight: haversine(state.start, aed) }))
      .sort((a, b) => a.straight - b.straight)
      .slice(0, CONFIG.candidateCount);

    const infos = await Promise.all(nearest.map((c) => computeInfo(c.aed)));
    if (token !== state.token) return;   // 後から別の検索が始まっていたら破棄

    infos.forEach((info) => state.cache.set(info.aed.id, info));
    state.ranked = infos.sort((a, b) => a.distance - b.distance);

    renderCandidates();
    const best = state.ranked[0];
    const offline = state.ranked.some((r) => r.approx);
    await showAED(best.aed);

    if (token !== state.token) return;
    if (state.outside) {
      setStatus('出発地が' + CONFIG.areaName + '周辺の外です。このアプリは' + CONFIG.areaName + '内のAEDのみ対象です。', 'error');
    } else if (offline) {
      setStatus('一部の経路を取得できなかったため、直線距離から概算しています。', 'error');
    } else {
      setStatus('最寄りのAEDまでの最短経路を表示しました。');
    }
  }

  /* ===== 表示 ===== */
  async function showAED(aed) {
    state.selected = aed;
    refreshIcons();

    if (!state.start) {
      renderResult(aed, null);
      map.setView([aed.lat, aed.lng], 17);
      return;
    }

    let info = state.cache.get(aed.id);
    if (!info) {
      setStatus('経路を計算中…', 'busy');
      info = await computeInfo(aed);
      if (!state.start) return;
      state.cache.set(aed.id, info);
      setStatus('');
    }
    if (state.selected !== aed) return;

    renderResult(aed, info);
    drawRoute(info);
    markActiveCandidate();
  }

  function row(dl, label, value, href) {
    if (!value) return;
    dl.appendChild(el('dt', null, label));
    const dd = el('dd');
    if (href) {
      const a = el('a', null, value);
      a.href = href;
      dd.appendChild(a);
    } else {
      dd.textContent = value;
    }
    dl.appendChild(dd);
  }

  function renderResult(aed, info) {
    const box = ui.result;
    box.textContent = '';

    const rankIndex = state.ranked.findIndex((r) => r.aed.id === aed.id);
    box.appendChild(el('span', 'tag', rankIndex === 0 ? '最寄りのAED' : '選択中のAED'));
    box.appendChild(el('h2', null, aed.name));

    if (info) {
      const d = formatDistance(info.distance);
      const dist = el('p', 'dist');
      dist.appendChild(el('strong', null, d.value + ' ' + d.unit));
      dist.appendChild(el('span', null, '徒歩 約' + walkMinutes(info.distance) + '分'));
      box.appendChild(dist);
      if (info.approx) box.appendChild(el('p', 'approx', '※ 経路を取得できないため、直線距離からの概算です。'));
      if (aed.geocoded) {
        box.appendChild(el('p', 'approx', '※ この位置は住所から自動取得したもので、数十m程度ずれる場合があります。現地で設置場所を確認してください。'));
      }
      if (info.distance > 2000) {
        box.appendChild(el('p', 'approx', '※ 距離があります。車や自転車で取りに行けるか、周囲の人に相談してください。'));
      }
    }

    const dl = el('dl');
    row(dl, '住所', aed.address);
    row(dl, '設置場所', aed.place);
    row(dl, '利用時間', aed.hours);
    row(dl, '電話', aed.tel, aed.tel ? 'tel:' + aed.tel.replace(/[^\d+]/g, '') : '');
    row(dl, '備考', aed.note);
    if (dl.children.length) box.appendChild(dl);

    const dest = aed.lat + ',' + aed.lng;
    const origin = state.start ? '&origin=' + state.start.lat + ',' + state.start.lng : '';
    const link = el('a', 'nav-link', 'Googleマップで道案内を開く');
    link.href = 'https://www.google.com/maps/dir/?api=1' + origin + '&destination=' + dest + '&travelmode=walking';
    link.target = '_blank';
    link.rel = 'noopener';
    box.appendChild(link);

    box.hidden = false;
  }

  function renderCandidates() {
    ui.candList.textContent = '';
    state.ranked.forEach((r, i) => {
      const li = el('li');
      const btn = el('button', 'cand-item');
      btn.type = 'button';
      btn.dataset.id = r.aed.id;

      btn.appendChild(el('span', 'rank', String(i + 1)));

      const nm = el('span', 'nm', r.aed.name);
      if (r.aed.is24h) nm.appendChild(el('span', 'tag24', '24h'));
      btn.appendChild(nm);

      const d = formatDistance(r.info ? r.info.distance : r.distance);
      btn.appendChild(el('span', 'ds', (r.approx ? '約' : '') + d.value + d.unit));

      btn.addEventListener('click', () => showAED(r.aed));
      li.appendChild(btn);
      ui.candList.appendChild(li);
    });
    ui.candidates.hidden = false;
    markActiveCandidate();
  }

  function markActiveCandidate() {
    ui.candList.querySelectorAll('.cand-item').forEach((btn) => {
      const active = state.selected && Number(btn.dataset.id) === state.selected.id;
      if (active) btn.setAttribute('aria-current', 'true');
      else btn.removeAttribute('aria-current');
    });
  }

  /* ===== 初期化 ===== */
  function bindEvents() {
    ui.btnLocate.addEventListener('click', locate);
    ui.btnPick.addEventListener('click', () => {
      const next = !state.picking;
      setPicking(next);
      if (!next) setStatus('');
    });
    ui.chk24.addEventListener('change', () => {
      state.only24 = ui.chk24.checked;
      refreshIcons();
      if (state.start) search();
    });
  }

  async function init() {
    initMap();
    bindEvents();

    try {
      const loaded = await loadAEDs();
      let aeds = loaded.aeds;
      let failed = 0;

      if (loaded.pending.length) {
        setStatus('住所からAEDの位置を取得中…', 'busy');
        const g = await geocodePending(loaded.pending);
        aeds = aeds.concat(g.resolved);
        failed = g.failed;
      }
      if (!aeds.length) throw new Error('empty');

      state.aeds = aeds;
      addMarkers();

      ui.btnLocate.disabled = false;
      ui.btnPick.disabled = false;
      const outCount = aeds.filter((a) => !inArea(a)).length;
      const geoCount = aeds.filter((a) => a.geocoded).length;
      ui.dataInfo.textContent = 'AEDデータ: ' + aeds.length + '件を登録' +
        (geoCount ? '（うち' + geoCount + '件は住所から位置を取得）' : '') +
        (loaded.skipped ? '／座標不備の' + loaded.skipped + '件を除く' : '') +
        (failed ? '／位置を取得できなかった' + failed + '件を除く' : '') +
        (outCount ? '／' + CONFIG.areaName + '外の座標が' + outCount + '件あります' : '');
      if (failed) {
        setStatus('一部のAEDの位置を取得できませんでした（' + failed + '件）。通信状況を確認して再読み込みしてください。', 'error');
      } else {
        setStatus('ボタンを押すと、現在地から最も近い' + CONFIG.areaName + '内のAEDを探します。');
      }
    } catch (e) {
      const messages = {
        fetch: 'AED.xlsx を読み込めません。GitHub Pages上、またはローカルサーバー（例: python -m http.server）で開いてください。',
        columns: 'AED.xlsx に「緯度」「経度」の列が見つかりません。1行目の見出しを確認してください。',
        empty: 'AED.xlsx に有効なデータ（施設名・緯度・経度）がありません。'
      };
      setStatus(messages[e && e.message] || messages.fetch, 'error');
      console.error(e);
    }
  }

  init();
})();
